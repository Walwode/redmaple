# redmaple

RedMaple is a project to read battery powered arduino nano/mini pro sensors by NRF24LF01 to an ESP8266. The values are stored into a website based on REST communication.
